import asyncio

import pygame
from sys import exit

# spied
FPS = 60
# colors
PINK = 252, 0, 252
BLACK = 0, 0, 0
white = 255, 255, 255

pygame.init()
screen = pygame.display.set_mode((768, 512))
pygame.display.set_caption("ישיבה מריו")
# images:
guy_run1 = pygame.image.load("run_guy1.png").convert_alpha()
guy_run1.set_colorkey(PINK)
guy_run1_rect = guy_run1.get_rect(topleft=(70, 285))
guy_run2 = pygame.image.load("run_guy2.png").convert()
guy_run2.set_colorkey(PINK)
guy_run3 = pygame.image.load("run_guy3.png").convert()
guy_run3.set_colorkey(PINK)
guy_run4 = pygame.image.load("run_guy4.png").convert_alpha()
guy_run4.set_colorkey(PINK)
bec = pygame.image.load('bec.jpg').convert()
bec2 = pygame.image.load('‏‏bec2.jpg').convert()
# time
clock = pygame.time.Clock()
# gravity and
graviyt_plyer = 0
biger_speed = 0
move = 0
move_back = 768
max_speed = 20
slow_speed = 0

async def main():
    global move, move_back, biger_speed, slow_speed, graviyt_plyer
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
    #
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and guy_run1_rect.bottom == 470:
                    graviyt_plyer = -20


    # screen building
        screen.blit(bec, (move, 0))
        screen.blit(bec2, (move_back, 0))
        keys = pygame.key.get_pressed()
    # background move
        if keys[pygame.K_RIGHT]:
            if biger_speed >= max_speed:
                biger_speed = max_speed
            else:
                biger_speed += 0.1
            if move <= 0:
                move -= biger_speed
                move_back = move + 768
            if move_back <= 0:
                move_back -= biger_speed
                move = move_back + 768
        else:
            if biger_speed <= 0:
                biger_speed = 0
            elif biger_speed > 0:
                slow_speed = biger_speed / biger_speed
                biger_speed -= slow_speed
                if move <= 0:
                    move -= biger_speed
                    move_back = move + 768
                if move_back <= 0:
                    move_back -= biger_speed
                    move = move_back + 768


    # building
        # refresh image
        clock.tick(FPS)
        # gravity maek
        graviyt_plyer += 1
        guy_run1_rect.y += graviyt_plyer
        # check tach in teh ground
        if guy_run1_rect.bottom >= 470:
            guy_run1_rect.bottom = 470
        # build plyer and rectangle plyer together
        screen.blit(guy_run1, guy_run1_rect)






        pygame.display.update()
        await asyncio.sleep(0)

asyncio.run(main())
